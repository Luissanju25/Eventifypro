import { createContext, useState, useEffect } from 'react'
import { getEvents } from '../api/events'

export const EventsContext = createContext()

export const EventsProvider = ({ children }) => {
  const [events, setEvents] = useState([])

  const [filter, setFilter] = useState("Todos")

  useEffect(() => {
    const loadEvents = async () => {
      const data = await getEvents()
      setEvents(data)
    }

    loadEvents()
  }, [])

  const addEvent = (newEvent) => {
    setEvents(prev => [...prev, newEvent])
  }

  const filteredEvents = filter === "Todos"
  ? events
  : events.filter(e => e.category === filter)

  return (
<EventsContext.Provider value={{ events: filteredEvents, addEvent, setFilter, filter }}>  
      {children}
    </EventsContext.Provider>
  )
}