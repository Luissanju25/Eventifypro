import { useState, useEffect } from 'react'
import { getEvents } from '../api/events'

export const useEvents = () => {
  const [events, setEvents] = useState([])

  useEffect(() => {
    const loadEvents = async () => {
      try {
        const data = await getEvents()
        setEvents(data)
      } catch (error) {
        console.error("Error cargando eventos", error)
      }
    }

    loadEvents()
  }, [])

  return { events }
}