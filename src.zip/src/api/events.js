const events = [
  {
    id: 1,
    title: "Concierto de Rock",
    description: "Gran concierto en vivo",
    date: "2026-06-10",
    location: "Madrid",
    category: "Música",
    price: 25
  },
  {
    id: 2,
    title: "Feria Tecnológica",
    description: "Innovaciones del futuro",
    date: "2026-07-15",
    location: "Barcelona",
    category: "Tecnología",
    price: 10
  }
]

// Simula llamada a API
export const getEvents = async () => {
  return new Promise((resolve) => {
    setTimeout(() => {
      const storedEvents = JSON.parse(localStorage.getItem("events"))

      if (storedEvents && storedEvents.length > 0) {
        resolve(storedEvents)
      } else {
        resolve(events) // los iniciales
      }
    }, 500)
  })
}

export const getEventById = async (id) => {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      const storedEvents = JSON.parse(localStorage.getItem("events")) || []

      const allEvents = storedEvents.length > 0 ? storedEvents : events

      const event = allEvents.find(e => e.id === parseInt(id))

      if (event) {
        resolve(event)
      } else {
        reject("Evento no encontrado")
      }
    }, 500)
  })
}

export const saveEvent = async (newEvent) => {
  return new Promise((resolve) => {
    setTimeout(() => {
      const storedEvents = JSON.parse(localStorage.getItem("events")) || []

      const updatedEvents = [...storedEvents, newEvent]

      localStorage.setItem("events", JSON.stringify(updatedEvents))

      resolve(newEvent)
    }, 500)
  })
}