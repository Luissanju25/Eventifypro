import { useState } from 'react'
import { saveEvent } from '../api/events'
import { useContext } from 'react'
import { EventsContext } from '../context/EventsContext'
import Event from '../models/Event'

function Create() {
  const { addEvent } = useContext(EventsContext)
  
  const [form, setForm] = useState({
    title: '',
    description: '',
    date: '',
    location: '',
    category: '',
    price: ''
  })

  const handleChange = (e) => {
    setForm({
      ...form,
      [e.target.name]: e.target.value
    })
  }

const handleSubmit = async (e) => {
  e.preventDefault()

  if (!form.title || !form.date || !form.location) {
    alert("Todos los campos obligatorios deben rellenarse")
    return
  }

  const newEvent = new Event({
  ...form,
  id: Date.now()
})

  try {
    await saveEvent(newEvent)
    addEvent(newEvent) // 🔥 ACTUALIZA EN TIEMPO REAL
    alert("Evento creado correctamente")
  } catch (error) {
    console.error(error)
  }
}

  return (
  <div style={{ maxWidth: "500px", margin: "20px auto" }}>
    <h1>Crear evento</h1>

    <form onSubmit={handleSubmit} style={{ display: "flex", flexDirection: "column", gap: "10px" }}>
      <input name="title" placeholder="Título" onChange={handleChange} />
      <input name="location" placeholder="Ubicación" onChange={handleChange} />
      <input name="date" type="date" onChange={handleChange} />
      <select name="category" onChange={handleChange}>
        <option value="">Selecciona categoría</option>
        <option value="Moros y cristianos">Moros y cristianos</option>
        <option value="Teatro">Teatro</option>
        <option value="Conciertos">Conciertos</option>
        <option value="Orquesta">Orquesta</option>
        <option value="Deportes">Deportes</option>
        <option value="Otros">Otros</option>
      </select>
      <input name="price" type="number" placeholder="Precio" onChange={handleChange} />
      <textarea name="description" placeholder="Descripción" onChange={handleChange}></textarea>

      <button type="submit">Crear</button>
    </form>
  </div>
)
}

export default Create