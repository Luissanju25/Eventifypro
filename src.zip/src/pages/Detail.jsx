import { useParams } from 'react-router-dom'
import { useEffect, useState } from 'react'
import { getEventById } from '../api/events'

function Detail() {
  const { id } = useParams()
  const [event, setEvent] = useState(null)

  useEffect(() => {
    const loadEvent = async () => {
      try {
        const data = await getEventById(id)
        setEvent(data)
      } catch (error) {
        console.error(error)
      }
    }

    loadEvent()
  }, [id])

  if (!event) return <p>Cargando...</p>

  return (
    <div>
      <h1>{event.title}</h1>
      <p>{event.description}</p>
      <p>{event.location}</p>
      <p>{event.date}</p>
    </div>
  )
}

export default Detail