import { useContext } from 'react'
import { EventsContext } from '../context/EventsContext'
import EventList from '../components/EventList'

function Home() {
  const { events } = useContext(EventsContext)

  return (
    <div style={{ maxWidth: "800px", margin: "20px auto" }}>
      <h1>Lista de eventos</h1>
      <EventList events={events} />
    </div>
  )
}
export default Home