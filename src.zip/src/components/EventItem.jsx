import { Link } from 'react-router-dom'

function EventItem({ event }) {
  return (
    <div style={{
      border: "1px solid #ccc",
      padding: "15px",
      margin: "10px 0",
      borderRadius: "8px",
      backgroundColor: "#f9f9f9"
    }}>
      <Link to={`/event/${event.id}`}>
        <h3>{event.title}</h3>
      </Link>

      <p>
        <strong>Resumen:</strong>{" "}
        {event.getSummary ? event.getSummary() : `${event.title} - ${event.location}`}
      </p>

      <p><strong>📍</strong> {event.location}</p>
      <p><strong>📅</strong> {event.date}</p>
      <p><strong>💰</strong> {event.price}€</p>
    </div>
  )
}

export default EventItem