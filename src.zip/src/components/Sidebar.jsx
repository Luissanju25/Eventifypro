import { useContext } from 'react'
import { EventsContext } from '../context/EventsContext'

function Sidebar() {
  const { setFilter, filter } = useContext(EventsContext)

  const categories = [
    "Todos",
    "Moros y cristianos",
    "Teatro",
    "Conciertos",
    "Orquesta",
    "Deportes",
    "Otros"
  ]

  return (
    <aside style={{
      width: "200px",
      padding: "15px",
      backgroundColor: "#f0f0f0"
    }}>
      <h3>Categorías</h3>

      <ul style={{ listStyle: "none", padding: 0 }}>
        {categories.map(cat => (
          <li
            key={cat}
            onClick={() => setFilter(cat)}
            style={{
              cursor: "pointer",
              padding: "5px",
              marginBottom: "5px",
              borderRadius: "5px",
              backgroundColor: filter === cat ? "#ddd" : "transparent",
              fontWeight: filter === cat ? "bold" : "normal"
            }}
            onMouseEnter={(e) => e.target.style.backgroundColor = "#eee"}
            onMouseLeave={(e) => {
              if (filter !== cat) {
                e.target.style.backgroundColor = "transparent"
              }
            }}
          >
            {cat}
          </li>
        ))}
      </ul>
    </aside>
  )
}

export default Sidebar