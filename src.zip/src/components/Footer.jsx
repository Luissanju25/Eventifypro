function Footer() {
  return (
    <footer style={{
      backgroundColor: "#222",
      color: "white",
      textAlign: "center",
      padding: "10px",
      marginTop: "20px"
    }}>
      <p>© 2026 EventifyPro</p>
    </footer>
  )
}

export default Footer