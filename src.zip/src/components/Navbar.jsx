import { Link } from 'react-router-dom'

function Navbar() {
  return (
    <nav style={{
      display: "flex",
      justifyContent: "space-between",
      padding: "10px 20px",
      backgroundColor: "#222",
      color: "white"
    }}>
      <h2>EventifyPro</h2>

      <div>
        <Link style={{ color: "white", marginRight: "15px" }} to="/">Inicio</Link>
        <Link style={{ color: "white" }} to="/create">Crear Evento</Link>
      </div>
    </nav>
  )
}

export default Navbar